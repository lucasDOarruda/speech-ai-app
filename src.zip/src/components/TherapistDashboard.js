import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { auth, db } from '../firebase';
import { collection, query, where, getDocs, doc, getDoc, updateDoc } from 'firebase/firestore';
import ChatWindow from './ChatWindow';

export default function TherapistDashboard() {
  const navigate = useNavigate();
  const currentUser = auth.currentUser;
  const [connectedClients, setConnectedClients] = useState([]);
  const [pendingRequests, setPendingRequests] = useState([]);
  const [selectedClientId, setSelectedClientId] = useState(null);

  useEffect(() => {
    if (!currentUser) return;

    const fetchConnections = async () => {
      const q = query(collection(db, 'connections'), where('therapistId', '==', currentUser.uid));
      const snapshot = await getDocs(q);

      const pending = [];
      const accepted = [];

      for (const conn of snapshot.docs) {
        const data = conn.data();
        const userSnap = await getDoc(doc(db, 'users', data.clientId));
        const user = userSnap.data();

        if (data.status === 'pending') {
          pending.push({ id: conn.id, ...data, user });
        } else if (data.status === 'accepted') {
          accepted.push({ id: conn.id, ...data, user });
        }
      }

      setPendingRequests(pending);
      setConnectedClients(accepted);
    };

    fetchConnections();
  }, [currentUser]);

  const handleAccept = async (connectionId) => {
    await updateDoc(doc(db, 'connections', connectionId), { status: 'accepted' });
    window.location.reload();
  };

  return (
    <div className="p-6 bg-gradient-to-br from-blue-50 via-yellow-50 to-white min-h-screen">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-blue-700">👩‍⚕️ Therapist Dashboard</h2>
        <p className="text-gray-600">Manage connection requests and access your tools.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-5xl mx-auto">
        <DashboardCard title="📝 Transcribe Sessions" onClick={() => navigate('/transcribe')} desc="Transcribe live sessions and export notes." />
        <DashboardCard title="🌿 Practice Exercises" onClick={() => navigate('/exercises')} desc="Browse and assign exercises to clients." />
        <DashboardCard title="💬 Chat" onClick={() => setSelectedClientId(null)} desc="Chat with clients in real time." />
        <DashboardCard title="📄 Assessments" onClick={() => navigate('/assessments')} desc="Send or view assigned assessments." />
        <DashboardCard title="📉 Progress Tracking" onClick={() => navigate('/progress')} desc="Track patient improvement and points." />
      </div>

      <div className="mt-12 max-w-5xl mx-auto">
        <h3 className="text-xl font-semibold text-blue-800 mb-2">Pending Requests</h3>
        {pendingRequests.length === 0 ? (
          <p className="text-gray-500">No pending requests.</p>
        ) : (
          pendingRequests.map((req) => (
            <div key={req.id} className="bg-yellow-100 rounded p-4 mb-2 flex justify-between items-center">
              <p className="text-gray-700">{req.user?.email} wants to connect.</p>
              <button onClick={() => handleAccept(req.id)} className="bg-green-600 text-white px-4 py-1 rounded hover:bg-green-700">Accept</button>
            </div>
          ))
        )}
      </div>

      <div className="mt-10 max-w-5xl mx-auto">
        <h3 className="text-xl font-semibold text-blue-800 mb-2">Connected Clients</h3>
        {connectedClients.length === 0 ? (
          <p className="text-gray-500">No connected clients.</p>
        ) : (
          <div className="grid grid-cols-2 gap-4">
            {connectedClients.map((client) => (
              <div key={client.id} className="bg-green-100 p-4 rounded flex justify-between items-center">
                <div>{client.user?.email}</div>
                <button onClick={() => setSelectedClientId(client.clientId)} className="bg-blue-600 text-white px-3 py-1 rounded hover:bg-blue-700">Chat</button>
              </div>
            ))}
          </div>
        )}
      </div>

      {selectedClientId && (
        <div className="mt-12 max-w-5xl mx-auto bg-white rounded-xl shadow p-6">
          <h4 className="text-lg font-semibold mb-4 text-blue-600">Chat with Client</h4>
          <ChatWindow receiverId={selectedClientId} />
        </div>
      )}
    </div>
  );
}

const DashboardCard = ({ title, desc, onClick }) => (
  <div onClick={onClick} className="cursor-pointer bg-white shadow-md hover:shadow-lg rounded-2xl p-6 transition transform hover:scale-105">
    <h3 className="text-xl font-bold text-blue-800 mb-1">{title}</h3>
    <p className="text-gray-700">{desc}</p>
  </div>
);
