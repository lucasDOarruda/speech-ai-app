import React from 'react';
import LoginPage from './LoginPage';

export default function LoginTherapist() {
  return <LoginPage role="therapist" />;
}
