import React from 'react';
import LoginPage from './LoginPage';

export default function LoginClient() {
  return <LoginPage role="client" />;
}
