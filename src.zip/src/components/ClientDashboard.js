import React, { useState, useEffect } from 'react';
import { db, auth } from '../firebase';
import { collection, onSnapshot, query, where } from 'firebase/firestore';
import ChatWindow from './ChatWindow';

const ClientDashboard = () => {
  const [therapists, setTherapists] = useState([]);
  const [selectedTherapist, setSelectedTherapist] = useState(null);

  const currentUser = auth.currentUser;

  useEffect(() => {
    if (!currentUser) return;

    const q = query(
      collection(db, 'users'),
      where('role', '==', 'therapist')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const therapistList = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data(),
      }));
      setTherapists(therapistList);
    });

    return () => unsubscribe();
  }, [currentUser]);

  return (
    <div className="min-h-screen p-4">
      <h2 className="text-2xl font-bold text-center mb-6">Client Dashboard</h2>

      <div className="flex space-x-4">
        <div className="flex flex-col w-1/3 p-4 bg-gray-100 rounded-md">
          <h3 className="font-bold mb-4">Available Therapists</h3>
          {therapists.map((therapist) => (
            <div
              key={therapist.id}
              onClick={() => setSelectedTherapist(therapist.id)}
              className="p-2 mb-2 bg-white border rounded cursor-pointer hover:bg-gray-200"
            >
              {therapist.email}
            </div>
          ))}
        </div>

        {selectedTherapist && (
          <div className="flex-1 p-4 bg-gray-100 rounded-md">
            <ChatWindow receiverId={selectedTherapist} />
          </div>
        )}
      </div>
    </div>
  );
};

export default ClientDashboard;
